"""write a script that prints the multiples of 7 between 0 and 100 python
 write a script that prints the multiples of 7 between 0 and 100 python	"""
			


l=[]
for i in  range(0,100):
	if i%7==0:
		l.append(i)
print(l)
    