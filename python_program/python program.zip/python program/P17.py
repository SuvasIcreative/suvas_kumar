#17). Please write a program to shuffle and print the list [3,6,7,8].


from random import shuffle
list1 = [5,4,3,2,1]
shuffle(list1)
print(list1)