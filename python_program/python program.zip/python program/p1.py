import datetime
 
 
 
dt_now = datetime.datetime.now()
 
 
 
print('Current Local Date:', dt_now)
 
add_days = dt_now + datetime.timedelta(days=7)
 
print('Adding Seven days: ', add_days)