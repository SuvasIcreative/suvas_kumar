"""6). Write a program that accepts a sentence and calculate 
the number of uppercase letters and lowercase letters.
Suppose the following input is supplied to the program:
Hello world!
Then, the output should be:
UPPER CASE 1
LOWER CASE 9
"""


no_of_lines = int(input("Enter numbr of line u want to write: "))
lines = ""
upper=0
lower=0

for i in range(no_of_lines):
    lines+=input()+"\n"

for j in range(len(lines)):
    
      if(lines[j]>='a' and lines[j]<='z'):
          lower+=1
      
      elif(lines[j]>='A' and lines[j]<='Z'):
          upper+=1

print('Lower case letters= ',lower)
print('Upper case letters=' ,upper)


