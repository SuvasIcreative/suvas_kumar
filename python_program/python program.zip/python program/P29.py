
"""29). Please write a program which accepts a string from 
the console and prints it in reverse order.
If the following string is given as input to the program:
rise to vote sir
Then, the output of the program should be:
ris etov ot esir
"""



text = str(input("Enter str :"))[::-1]
print(text)