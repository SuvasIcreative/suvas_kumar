

Create A Contact Sale Model
----------------------

In this model we give some details about concat

Sale Order 
-------------------------------

In this field we acese to take only sale order which releted to contact


follow UPS
-------------------------------

User can give number of follow UPS

concat history
-------------------------------
In concat history manage details:
-create Date
-create By
-old state
-new state
-old number of follow detail
-new number of follow detail


